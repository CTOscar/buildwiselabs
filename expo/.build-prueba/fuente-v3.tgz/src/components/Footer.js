import { View, Text, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';

import BuildWiseLogo from './BuildWiseLogo';
import Button from './ui/Button';
import { CARD_SERVICES } from '../constants/services';

const SOCIALS = [
  { icon: 'logo-instagram', label: 'Instagram', url: 'https://instagram.com/buildwiselabs' },
  { icon: 'logo-linkedin',  label: 'LinkedIn',  url: 'https://linkedin.com/company/buildwiselabs' },
  { icon: 'logo-github',    label: 'GitHub',    url: 'https://github.com/buildwiselabs' },
  { icon: 'logo-whatsapp',  label: 'WhatsApp',  url: 'https://wa.me/521XXXXXXXXXX' },
];

// Paginas del sitio.
const EMPRESA = [
  { label: 'Nosotros', route: 'Nosotros' },
  { label: 'Documentación', route: 'Docs' },
  { label: 'Labs', route: 'Labs' },
  { label: 'Contacto', route: 'Contacto' },
  { label: 'Iniciar sesión', route: 'Login' },
];

const HERRAMIENTAS = [
  { label: 'Chatbot', route: 'Chatbot' },
  { label: 'Visor de reportes', route: 'Reportes' },
];

// Fuentes externas que integramos en los proyectos. Van aparte de las paginas del sitio
// y se abren en otra pestana: son de terceros, no nuestras.
const RECURSOS = [
  { label: 'Banco Central (Banxico)', url: 'https://www.banxico.org.mx' },
  { label: 'Mercado cripto', url: 'https://www.coingecko.com' },
  { label: 'API de mapas', url: 'https://developers.google.com/maps' },
  { label: 'OpenStreetMap', url: 'https://www.openstreetmap.org' },
  { label: 'Datos del clima', url: 'https://open-meteo.com' },
];

export default function Footer() {
  const navigation = useNavigation();
  const abrir = (url) => {
    if (typeof window !== 'undefined') window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <View className="w-full bg-carbon-black px-5 pb-10 pt-16">
      <View className="mx-auto w-full max-w-5xl">
        {/* Llamada a la accion: el footer es el final de cada pagina, y quien llega
            hasta aqui leyendo es justo a quien hay que darle por donde seguir. */}
        <View className="mb-14 flex-row flex-wrap items-center justify-between gap-6 border-b border-carbon-gray90 pb-12">
          <View className="min-w-[280px] flex-1">
            <Text className="font-plexlight text-3xl leading-10 text-white">
              ¿Listo para automatizar tu operación?
            </Text>
            <Text className="mt-3 max-w-lg font-plex text-sm leading-6 text-carbon-gray50">
              Cuéntanos qué necesitas y te respondemos con una propuesta concreta.
            </Text>
          </View>
          <Button label="Hablemos" variant="pill" onPress={() => navigation.navigate('Contacto')} />
        </View>

        <View className="flex-row flex-wrap gap-y-10">
          {/* Marca */}
          <View className="min-w-[260px] flex-[1.4] pr-8">
            <BuildWiseLogo height={28} variant="light" />
            <Text className="mt-4 max-w-xs font-plex text-sm leading-6 text-carbon-gray50">
              Diseñamos sistemas inteligentes que automatizan operaciones y
              hacen crecer negocios.
            </Text>
            <View className="mt-6 flex-row gap-2">
              {SOCIALS.map((s) => (
                <Pressable
                  key={s.label}
                  onPress={() => abrir(s.url)}
                  accessibilityLabel={s.label}
                  className="h-10 w-10 items-center justify-center border border-carbon-gray90 hover:border-carbon-blue hover:bg-carbon-gray90"
                >
                  <Ionicons name={s.icon} size={18} color="#c6c6c6" />
                </Pressable>
              ))}
            </View>
          </View>

          <Columna title="Servicios">
            {CARD_SERVICES.map((s) => (
              <Enlace
                key={s.id}
                label={s.title}
                onPress={() => navigation.navigate('Servicio', { id: s.id })}
              />
            ))}
          </Columna>

          <Columna title="Empresa">
            {EMPRESA.map((c) => (
              <Enlace key={c.route} label={c.label} onPress={() => navigation.navigate(c.route)} />
            ))}
          </Columna>

          <Columna title="Herramientas">
            {HERRAMIENTAS.map((h) => (
              <Enlace key={h.route} label={h.label} onPress={() => navigation.navigate(h.route)} />
            ))}
          </Columna>

          <Columna title="Recursos">
            {RECURSOS.map((r) => (
              <Enlace key={r.url} label={r.label} externo onPress={() => abrir(r.url)} />
            ))}
          </Columna>
        </View>

        <View className="mt-14 flex-row flex-wrap items-center justify-between gap-3 border-t border-carbon-gray90 pt-6">
          <Text className="font-plex text-xs text-carbon-gray50">
            © 2026 BuildWise Labs. Todos los derechos reservados.
          </Text>
          <Text className="font-plex text-xs text-carbon-gray50">
            Hecho en México
          </Text>
        </View>
      </View>
    </View>
  );
}

function Columna({ title, children }) {
  return (
    <View className="min-w-[170px] flex-1">
      <Text className="mb-4 font-plexsemibold text-xs uppercase tracking-[2px] text-white">
        {title}
      </Text>
      <View className="gap-3">{children}</View>
    </View>
  );
}

/** Un enlace del footer. `externo` marca los que salen del sitio, con su flechita. */
function Enlace({ label, onPress, externo }) {
  return (
    <Pressable onPress={onPress} className="flex-row items-center gap-1.5 self-start">
      <Text className="font-plex text-sm text-carbon-gray50 hover:text-white">{label}</Text>
      {externo ? <Ionicons name="open-outline" size={12} color="#6f6f6f" /> : null}
    </Pressable>
  );
}

import { useEffect, useState } from 'react';
import { View, Text, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import Screen from '../components/ui/Screen';
import Starfield from '../components/ui/Starfield';
import GuideShowcase from '../components/GuideShowcase';
import ServiceSidebar from '../components/ServiceSidebar';
import { SERVICES } from '../constants/services';

// Solo los servicios que traen guia tecnica (campo `guide` en constants/services.js).
const CON_GUIA = SERVICES.filter((s) => s.guide?.length > 0);

/**
 * Labs: el lado tecnico. Aqui viven las guias de inicio rapido (codigo reproducible,
 * vista previa, el video de campo) y la documentacion de cada servicio, que antes
 * estaban dentro de las paginas de servicio. Las paginas de servicio quedan para
 * explicar que ofrecemos; quien quiera ver como esta hecho, entra aqui.
 *
 * La guia abierta va en la URL (/labs?guia=automatizacion) para poder compartir el
 * enlace directo y para que el boton "Ver la guia tecnica" de cada servicio llegue a la
 * suya.
 */
export default function LabsScreen({ route, navigation }) {
  const pedida = route?.params?.guia;
  const valida = (id) => CON_GUIA.some((s) => s.id === id);
  const [id, setId] = useState(valida(pedida) ? pedida : CON_GUIA[0]?.id);

  useEffect(() => {
    if (valida(pedida)) setId(pedida);
  }, [pedida]);

  const elegir = (nuevo) => {
    setId(nuevo);
    navigation.setParams({ guia: nuevo });
  };

  const service = CON_GUIA.find((s) => s.id === id) || CON_GUIA[0];

  const hero = () => (
    <View className="w-full overflow-hidden bg-carbon-night">
      <Starfield count={70} seed={23} />
      <View className="mx-auto w-full max-w-5xl px-5 pb-12 pt-14">
        <View className="flex-row items-center gap-2">
          <Ionicons name="flask-outline" size={18} color="#c498c2" />
          <Text className="font-plexsemibold text-xs uppercase tracking-wide text-carbon-blue">Labs</Text>
        </View>
        <Text className="mt-3 max-w-3xl font-plexlight text-4xl leading-[46px] text-white">
          Guías de inicio rápido
        </Text>
        <Text className="mt-4 max-w-2xl font-plex text-lg leading-7 text-carbon-gray20">
          El lado técnico de lo que construimos: código que puedes correr hoy, paso a paso, y la
          documentación de cada servicio.
        </Text>

        {/* Selector de guia */}
        <View className="mt-8 flex-row flex-wrap gap-2">
          {CON_GUIA.map((s) => {
            const activo = s.id === service?.id;
            return (
              <Pressable
                key={s.id}
                onPress={() => elegir(s.id)}
                accessibilityRole="tab"
                accessibilityState={{ selected: activo }}
                className={`flex-row items-center gap-2 rounded-full border px-4 py-2 ${
                  activo ? 'border-carbon-blue bg-carbon-blue' : 'border-white/20 hover:border-white/40'
                }`}
              >
                <Ionicons name={s.icon} size={16} color={activo ? '#ffffff' : '#c498c2'} />
                <Text className={`font-plexsemibold text-sm ${activo ? 'text-white' : 'text-carbon-gray20'}`}>{s.title}</Text>
              </Pressable>
            );
          })}
        </View>
      </View>
    </View>
  );

  const contenido = (
    <>
      {service ? <GuideShowcase key={service.id} service={service} onContact={() => navigation.navigate('Contacto')} /> : null}

      {/* Documentacion por servicio: el mismo arbol que antes estaba al costado de cada
          servicio (con los documentos de la base, si responde). */}
      <View className="mx-auto w-full max-w-5xl px-5 pb-16 pt-16">
        <View className="mb-6 flex-row items-center gap-2">
          <Ionicons name="book-outline" size={20} color="#9d6b99" />
          <Text className="font-plexsemibold text-2xl text-carbon-black dark:text-white">Documentación por servicio</Text>
        </View>
        <View style={{ maxWidth: 520 }}>
          <ServiceSidebar currentId={service?.id} navigation={navigation} />
        </View>
      </View>
    </>
  );

  return (
    <Screen hero={hero} prefooter={contenido}>
      {null}
    </Screen>
  );
}
